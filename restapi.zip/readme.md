[changes]

- ubah "nama" menjadi "dosen"
